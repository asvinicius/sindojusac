<head>
    <title>Assembleias | SINDOJUS-AC</title>
</head>
<section id="inner-headline">
    <div class="container">
        <div class="row">
            <div class="span4">
                <div class="inner-heading">
                    <h2>Assembleias</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="content">
    <div class="container">
        <div class="row">
            <div class="span8">
                
                <article>
                    <div class="row">
                        <div class="span8">
                            <div class="post-image">
                                <div class="post-heading">
                                    <h3><a href="#">This is an example of standard post format</a></h3>
                                </div>
                                <img src="img/dummies/blog/img1.jpg" alt="" />
                            </div>
                            <p>
                                Qui ut ceteros comprehensam. Cu eos sale sanctus eligendi, id ius elitr saperet, ocurreret pertinacia pri an. No mei nibh consectetuer, semper laoreet perfecto ad qui, est rebum nulla argumentum ei. Fierent adipisci iracundia est ei, usu timeam persius
                                ea. Usu ea justo malis, pri quando everti electram ei, ex homero omittam salutatus sed.
                            </p>
                            <div class="bottom-article">
                                <ul class="meta-post">
                                    <li><i class="icon-calendar"></i><a href="#"> Mar 23, 2013</a></li>
                                    <li><i class="icon-user"></i><a href="#"> Admin</a></li>
                                    <li><i class="icon-folder-open"></i><a href="#"> Blog</a></li>
                                    <li><i class="icon-comments"></i><a href="#">4 Comments</a></li>
                                </ul>
                                <a href="#" class="pull-right">Continue reading <i class="icon-angle-right"></i></a>
                            </div>
                        </div>
                    </div>
                </article>
                <article>
                    <div class="row">
                        <div class="span8">
                            <div class="post-image">
                                <div class="post-heading">
                                    <h3><a href="#">This is an example of standard post format</a></h3>
                                </div>
                                <img src="img/dummies/blog/img1.jpg" alt="" />
                            </div>
                            <p>
                                Qui ut ceteros comprehensam. Cu eos sale sanctus eligendi, id ius elitr saperet, ocurreret pertinacia pri an. No mei nibh consectetuer, semper laoreet perfecto ad qui, est rebum nulla argumentum ei. Fierent adipisci iracundia est ei, usu timeam persius
                                ea. Usu ea justo malis, pri quando everti electram ei, ex homero omittam salutatus sed.
                            </p>
                            <div class="bottom-article">
                                <ul class="meta-post">
                                    <li><i class="icon-calendar"></i><a href="#"> Mar 23, 2013</a></li>
                                    <li><i class="icon-user"></i><a href="#"> Admin</a></li>
                                    <li><i class="icon-folder-open"></i><a href="#"> Blog</a></li>
                                    <li><i class="icon-comments"></i><a href="#">4 Comments</a></li>
                                </ul>
                                <a href="#" class="pull-right">Continue reading <i class="icon-angle-right"></i></a>
                            </div>
                        </div>
                    </div>
                </article>
                <article>
                    <div class="row">
                        <div class="span8">
                            <div class="post-image">
                                <div class="post-heading">
                                    <h3><a href="#">This is an example of standard post format</a></h3>
                                </div>
                                <img src="img/dummies/blog/img1.jpg" alt="" />
                            </div>
                            <p>
                                Qui ut ceteros comprehensam. Cu eos sale sanctus eligendi, id ius elitr saperet, ocurreret pertinacia pri an. No mei nibh consectetuer, semper laoreet perfecto ad qui, est rebum nulla argumentum ei. Fierent adipisci iracundia est ei, usu timeam persius
                                ea. Usu ea justo malis, pri quando everti electram ei, ex homero omittam salutatus sed.
                            </p>
                            <div class="bottom-article">
                                <ul class="meta-post">
                                    <li><i class="icon-calendar"></i><a href="#"> Mar 23, 2013</a></li>
                                    <li><i class="icon-user"></i><a href="#"> Admin</a></li>
                                    <li><i class="icon-folder-open"></i><a href="#"> Blog</a></li>
                                    <li><i class="icon-comments"></i><a href="#">4 Comments</a></li>
                                </ul>
                                <a href="#" class="pull-right">Continue reading <i class="icon-angle-right"></i></a>
                            </div>
                        </div>
                    </div>
                </article>
                <div id="pagination">
                    <span class="all">Page 1 of 3</span>
                    <span class="current">1</span>
                    <a href="#" class="inactive">2</a>
                    <a href="#" class="inactive">3</a>
                </div>
            </div>
            <div class="span4">
                <aside class="right-sidebar">
                    <div class="widget">
                        <form class="form-search">
                            <input placeholder="Busque algo..." type="text" class="input-medium search-query">
                            <button type="submit" class="btn btn-square btn-theme">Buscar</button>
                        </form>
                    </div>
                    <div class="widget">
                        <h5 class="widgetheading">Notícias importantes</h5>
                        <ul class="recent">
                            <li>
                                <h6><a href="#">Lorem ipsum dolor sit</a></h6>
                                <p>
                                    Mazim alienum appellantur eu cu ullum officiis pro pri
                                </p>
                            </li>
                            <li>
                                <h6><a href="#">Maiorum ponderum eum</a></h6>
                                <p>
                                    Mazim alienum appellantur eu cu ullum officiis pro pri
                                </p>
                            </li>
                            <li>
                                <h6><a href="#">Et mei iusto dolorum</a></h6>
                                <p>
                                    Mazim alienum appellantur eu cu ullum officiis pro pri
                                </p>
                            </li>
                        </ul>
                    </div>
                </aside>
            </div>
        </div>
    </div>
</section>