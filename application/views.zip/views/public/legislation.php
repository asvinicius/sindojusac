<head>
    <title>Legislação | SINDOJUS-AC</title>
</head>
<section id="inner-headline">
    <div class="container">
        <div class="row">
            <div class="span4">
                <div class="inner-heading">
                    <h2>Legislação</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="content">
    <div class="container">
        <div class="row">
            <div class="span12">
                <h2>O nascimento do <strong>SINDOJUS-AC</strong></h2>
                <p>
                    Em 8 de dezembro de 2017, reunidos em Assembleia Geral, 
                    os oficiais de Justiça do Acre fundaram o Sindojus-AC 
                    (Sindicato dos Oficiais de Justiça do Acre). 
                </p>
                <p>
                    O objetivo é a representação sindical específica da categoria dos 
                    Oficiais de Justiça no Estado do Acre.
                </p>
                <p>
                    A Assembleia também elegeu a diretoria e o conselho fiscal 
                    da primeira gestão da organização. O primeiro presidente 
                    eleito é o oficial de Justiça James Cley Nascimento Borges 
                    e para vice foi eleito o oficial de Justiça Cleido Rodrigues 
                    da Silva e Silva.
                </p>
            </div>
        </div>
    </div>
</section>