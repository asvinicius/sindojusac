<head>
    <title>Estatuto | SINDOJUS-AC</title>
</head>
<section id="inner-headline">
    <div class="container">
        <div class="row">
            <div class="span4">
                <div class="inner-heading">
                    <h2>Estatuto</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="content">
    <div class="container">
        <div class="row">
            <div class="span12">
                <p>
                    O Estatuto do Sindicato dos Oficiais de Justiça do Acre -  <a href="<?= base_url('assets/arc/ESTATUTO_SINDICATO.pdf'); ?>" download>Download</a>
                    
                </p>
            </div>
        </div>
    </div>
</section>