<head>
    <title>Madelos | SINDOJUS-AC</title>
</head>
<section id="inner-headline">
    <div class="container">
        <div class="row">
            <div class="span4">
                <div class="inner-heading">
                    <h2>Modelos</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="content">
    <div class="container">
        <div class="row">
            <div class="span12">
                <p>
                    Modelo de Ofício - <a href="#" download>Download</a>
                    <br />
                    Modelo de Certidão - <a href="#" download>Download</a>
                </p>
            </div>
        </div>
    </div>
</section>