<head>
    <title>Diretoria | SINDOJUS-AC</title>
</head>
<section id="inner-headline">
    <div class="container">
        <div class="row">
            <div class="span4">
                <div class="inner-heading">
                    <h2>Diretoria</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="content">
    <div class="container">
        <div class="row">
            <div class="span6">
                <h2>Quem faz o <strong>SINDOJUS-AC</strong></h2>
            </div>
        </div>
        <div class="row">
            <div class="span3">
                <img src="<?= base_url('assets/img/dummies/team1.jpg'); ?>" alt="" class="img-polaroid" />
                <div class="roles">
                    <p class="lead">
                        <strong>James Cley</strong>
                    </p>
                    <p>
                        Presidente
                    </p>
                </div>
            </div>
            <div class="span3">
                <img src="<?= base_url('assets/img/dummies/team2.jpg'); ?>" alt="" class="img-polaroid" />
                <div class="roles">
                    <p class="lead">
                        <strong>Cleido Rodrigues</strong>
                    </p>
                    <p>
                        Vice-presidente
                    </p>
                </div>
            </div>
            <div class="span3">
                <img src="<?= base_url('assets/img/dummies/team3.jpg'); ?>" alt="" class="img-polaroid" />
                <div class="roles">
                    <p class="lead">
                        <strong>Lenildo Bessa</strong>
                    </p>
                    <p>
                        Tesoureiro
                    </p>
                </div>
            </div>
            <div class="span3">
                <img src="<?= base_url('assets/img/dummies/team4.jpg'); ?>" alt="" class="img-polaroid" />
                <div class="roles">
                    <p class="lead">
                        <strong>Jackson Maia</strong>
                    </p>
                    <p>
                        Diretor Jurídico
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>