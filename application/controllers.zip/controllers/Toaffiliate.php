<?php

defined('BASEPATH') OR exit('No direct');

class Toaffiliate extends CI_Controller {

    public function request() {
        
        $this->load->library('email');
        
        $name = $this->input->post('name');
        $email = $this->input->post('email');
        $number = $this->input->post('number');
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $ConfirmPassword = $this->input->post('ConfirmPassword');
        
        $this->email->from('sindojusac@gmail.com', 'SINDOJUS-AC');
        $this->email->to($email);
        $this->email->subject("Pedido de filiação");
        $this->email->message("Olá, ".$name.". \n"
                            . "Seu pedido de filiação foi recebido! \n"
                            . "Agora temos de seguir novos passos para concluir sua filiação ao SINDOJUS-AC: \n"
                            . "Imprima e preencha a ficha de filiação e de autorização de débito que está anexada à este e-mail \n"
                            . "O próximo passo é entregar a ficha assinada (fisicamente) na sede do SINDOJUS-AC. \n"
                            . "Após a conclusão da sua filiação, um email será enviado lhe informando. A partir de então seu acesso à área de filiados do site do SINDOJUS-AC será liberada."
                            . "Na área de filiados é possível encontrar modelos de documentos, informações sobre assembléias e transparência do SINDOJUS-AC.");
        $email->AddAttachment( '../assets/arc', 'filiacaoedebito.pdf' );

        if($this->email->send()){
            $sendmessage = array(
                "class" => "alert alert-success",
                "message" => "Mensagem enviada. Agradecemos o seu contato.");
        }else{
            $sendmessage = array(
                "class" => "alert alert-danger",
                "message" => "Não foi possível enviar sua mensagem");
        }

        $msg = array("sendmessage" => $sendmessage);

        $this->load->view('template/public/header');
        $this->load->view('public/contact', $msg);
        $this->load->view('template/public/footer');
    }

}

?>